create definer = root@`%` view view_name as
select `schema_name`.`student`.`id`         AS `id`,
       `schema_name`.`student`.`createdate` AS `createdate`,
       `schema_name`.`student`.`updatedate` AS `updatedate`,
       `schema_name`.`student`.`name`       AS `name`,
       `schema_name`.`student`.`birthdt`    AS `birthdt`,
       `schema_name`.`student`.`major`      AS `major`,
       `schema_name`.`student`.`mobile`     AS `mobile`,
       `schema_name`.`student`.`email`      AS `email`,
       `schema_name`.`student`.`gender`     AS `gender`,
       `schema_name`.`student`.`graduatedt` AS `graduatedt`
from `schema_name`.`student`;

-- comment on column view_name.id not supported: 학번

-- comment on column view_name.createdate not supported: 등록일시

-- comment on column view_name.updatedate not supported: 수정일시

-- comment on column view_name.name not supported: 학생명

-- comment on column view_name.birthdt not supported: 생일(YYMMDD)

-- comment on column view_name.major not supported: 학과코드

-- comment on column view_name.mobile not supported: 전화번호

-- comment on column view_name.email not supported: 이메일주소

-- comment on column view_name.gender not supported: 성별(0:여성, 1:남성)

-- comment on column view_name.graduatedt not supported: 졸업일

